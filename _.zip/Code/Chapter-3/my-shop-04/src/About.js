import React, { Component } from 'react';

class About extends Component {
  render() {
    return (
      <div>
		<p>This is a simple e-commerce application</p>
      </div>
    );
  }
}

export default About;